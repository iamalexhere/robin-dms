import Dashboard from "~/components/ui/Dashboard";

export default function DashboardPage() {
    return <Dashboard />;
}
