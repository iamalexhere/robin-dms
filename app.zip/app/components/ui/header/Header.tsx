import SidebarToggle from "./SidebarToggle";
//import Logo from "./Logo";
import NotificationBell from "./NotifBell";
import UserMenu from "./UserMenu";

export default function Header() {
  return (
    <header className="w-full flex justify-between items-center px-4 py-2 bg-black text-white shadow">
      <div className="flex items-center gap-4">
        <SidebarToggle />
        <Logo />
      </div>

      <div className="flex items-center gap-6">
        <NotificationBell />
        <UserMenu />
      </div>
    </header>
  );
}