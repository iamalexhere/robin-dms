import { FaBars } from "react-icons/fa";

export default function SidebarToggle() {
  return (
    <button className="text-white text-xl">
      <FaBars />
    </button>
  );
}